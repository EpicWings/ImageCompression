/*Pasca Robert-Paul 315CB*/
#include "declarations.h"

int main(int argc, char *argv[])
{
    ReadExecArg(argc, argv);

    return 0;
}